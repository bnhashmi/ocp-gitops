#!/bin/bash
set -e

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)

echo "=== EX380 Q2 RESET ==="
echo "Removing only LDAP-AUTH-EX380 while preserving prerequisite objects."

exec "$SCRIPT_DIR/setup.sh"
