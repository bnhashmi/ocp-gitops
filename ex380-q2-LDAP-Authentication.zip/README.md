# EX380 Q2 — LDAP Authentication Exam Pack v4

Target environment:

    API: https://api.ocp4.example.com:6443
    Admin: admin / redhatocp

LDAP:

    IDP:          LDAP-AUTH-EX380
    Server:       idm.ocp4.example.com
    Protocol:     ldaps
    Base DN:      cn=users,cn=accounts,dc=ocp4,dc=example,dc=com
    Bind DN:      uid=admin,cn=users,cn=accounts,dc=ocp4,dc=example,dc=com
    Bind password:redhatocp
    Query:        uid
    Mapping:      claim

Exact prerequisite object names:

    Secret:       ldap-secret
    CA ConfigMap: ca-config-map

Test login:

    developer / developer

## Safe default setup

    ./setup.sh

The default setup:

1. Backs up the current OAuth resource.
2. Extracts the bind password from `ldap-secret` if it exists.
3. Extracts `ca.crt` from `ca-config-map` if it exists.
4. Stores backups under:

       ./q2-backup/

5. Preserves `ldap-secret`.
6. Preserves `ca-config-map`.
7. Removes only the `LDAP-AUTH-EX380` IDP.

This is the recommended reset mode.

## Backup files

If the objects exist, the pack creates:

    q2-backup/bindPassword
    q2-backup/ca.crt
    q2-backup/oauth-cluster-before.yaml

## Recreate prerequisite objects

If the secret or ConfigMap is accidentally deleted:

    ./restore-prereqs.sh

This recreates:

    ldap-secret
    ca-config-map

from the saved bind password and CA certificate.

## Optional full exam simulation

If you explicitly want the candidate to create the secret and CA ConfigMap too:

    ./setup-full-exam.sh

That script:

1. creates the backups first
2. removes only `ldap-secret` and `ca-config-map`
3. leaves the backups available for recovery

## Grade

    ./grade.sh

## Login test

    ./test-login.sh

## Reference solution

    ./instructor/solution.sh
