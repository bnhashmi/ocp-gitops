# EX380 Q2 — LDAP Authentication Exam Pack

Target environment:

    API: https://api.ocp4.example.com:6443
    Cluster admin: admin / redhatocp

    IdP name: LDAP-AUTH-EX380
    Protocol: ldaps
    LDAP server: idm.ocp4.example.com
    Base DN: cn=users,cn=accounts,dc=ocp4,dc=example,dc=com
    Bind DN: uid=admin,cn=users,cn=accounts,dc=ocp4,dc=example,dc=com
    Bind password: redhatocp
    Query attribute: uid
    Mapping method: claim

    Test user: developer / developer

This pack preserves unrelated OAuth identity providers.

Usage:

    ./setup.sh
    # solve Q2
    ./grade.sh

Reset only this task:

    ./reset.sh

Reference solution:

    ./instructor/solution.sh
