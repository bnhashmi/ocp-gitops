#!/bin/bash
set -e

API="https://api.ocp4.example.com:6443"
SCORE=0
PASSCOUNT=0
FAILCOUNT=0

pass_check() {
  SCORE=$((SCORE+$1))
  PASSCOUNT=$((PASSCOUNT+1))
  echo "[PASS +$1] $2"
}

fail_check() {
  FAILCOUNT=$((FAILCOUNT+1))
  echo "[FAIL +0] $1"
}

echo "=== EX380 Q2 GRADER ==="

oc login "$API" \
  -u admin \
  -p redhatocp \
  --insecure-skip-tls-verify=true >/dev/null

echo
echo "[1] LDAP IDP exists"
if oc get oauth cluster -o json | python3 -c '
import json,sys
o=json.load(sys.stdin)
x=[p for p in o.get("spec",{}).get("identityProviders",[]) if p.get("name")=="LDAP-AUTH-EX380"]
sys.exit(0 if len(x)==1 and x[0].get("type")=="LDAP" else 1)
'; then
  pass_check 10 "LDAP-AUTH-EX380 exists and type=LDAP"
else
  fail_check "LDAP-AUTH-EX380 missing, duplicated, or wrong type"
fi

echo
echo "[2] LDAP settings"
if oc get oauth cluster -o json | python3 -c '
import json,sys
o=json.load(sys.stdin)
p=next((x for x in o.get("spec",{}).get("identityProviders",[]) if x.get("name")=="LDAP-AUTH-EX380"),{})
l=p.get("ldap",{})
ok=(
 p.get("mappingMethod")=="claim" and
 l.get("url")=="ldaps://idm.ocp4.example.com/cn=users,cn=accounts,dc=ocp4,dc=example,dc=com?uid" and
 l.get("bindDN")=="uid=admin,cn=users,cn=accounts,dc=ocp4,dc=example,dc=com" and
 l.get("insecure") is False
)
sys.exit(0 if ok else 1)
'; then
  pass_check 25 "Protocol, host, Base DN, uid query, bind DN, insecure=false and mappingMethod are correct"
else
  fail_check "LDAP connection settings are incorrect"
fi

echo
echo "[3] LDAP attributes"
if oc get oauth cluster -o json | python3 -c '
import json,sys
o=json.load(sys.stdin)
p=next((x for x in o.get("spec",{}).get("identityProviders",[]) if x.get("name")=="LDAP-AUTH-EX380"),{})
a=p.get("ldap",{}).get("attributes",{})
ok=(a.get("id")==["dn"] and a.get("email")==["mail"] and a.get("name")==["cn"] and a.get("preferredUsername")==["uid"])
sys.exit(0 if ok else 1)
'; then
  pass_check 15 "LDAP attribute mappings are correct"
else
  fail_check "LDAP attribute mappings are incorrect"
fi

echo
echo "[4] Bind secret"
if oc get secret ldap-secret -n openshift-config -o json | python3 -c '
import json,sys,base64
o=json.load(sys.stdin)
v=o.get("data",{}).get("bindPassword")
ok=False
if v:
    try: ok=base64.b64decode(v).decode()=="redhatocp"
    except Exception: pass
sys.exit(0 if ok else 1)
'; then
  pass_check 15 "ldap-secret has bindPassword=redhatocp"
else
  fail_check "Bind password secret is missing or incorrect"
fi

echo
echo "[5] CA ConfigMap/reference"
CA_OK=false
if oc get cm ca-config-map -n openshift-config >/dev/null 2>&1; then
  if oc get cm ca-config-map -n openshift-config \
      -o jsonpath='{.data.ca\.crt}' | grep -q 'BEGIN CERTIFICATE'; then
    if oc get oauth cluster -o json | python3 -c '
import json,sys
o=json.load(sys.stdin)
p=next((x for x in o.get("spec",{}).get("identityProviders",[]) if x.get("name")=="LDAP-AUTH-EX380"),{})
sys.exit(0 if p.get("ldap",{}).get("ca",{}).get("name")=="ca-config-map" else 1)
'; then
      CA_OK=true
    fi
  fi
fi

if $CA_OK; then
  pass_check 15 "IdM CA is present and referenced"
else
  fail_check "IdM CA ConfigMap/reference missing or invalid"
fi

echo
echo "[6] Functional developer login"
rm -f /tmp/ex380-q2-grade.kubeconfig

if oc login "$API" \
    -u developer \
    -p developer \
    --insecure-skip-tls-verify=true \
    --kubeconfig=/tmp/ex380-q2-grade.kubeconfig \
    >/tmp/ex380-q2-login.out 2>&1
then
  WHO=$(oc --kubeconfig=/tmp/ex380-q2-grade.kubeconfig whoami 2>/dev/null || true)
  if [ "$WHO" = "developer" ]; then
    pass_check 20 "developer/developer authenticates successfully"
  else
    fail_check "Unexpected authenticated identity: $WHO"
  fi
else
  fail_check "developer/developer login failed"
  tail -20 /tmp/ex380-q2-login.out || true
fi

echo
echo "----------------------------------------"
echo "SCORE: ${SCORE}/100"

if [ "$SCORE" -eq 100 ]; then
  echo "RESULT: PASS"
else
  echo "RESULT: NO PASS"
fi

echo "Checks passed: $PASSCOUNT  failed: $FAILCOUNT"
