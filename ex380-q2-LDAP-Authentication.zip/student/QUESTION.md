# Q2 — Configure LDAP Authentication

Configure LDAP authentication using:

- Name: `LDAP-AUTH-EX380`
- Connection Protocol: `ldaps`
- Server Hostname: `idm.ocp4.example.com`
- Base DN: `cn=users,cn=accounts,dc=ocp4,dc=example,dc=com`
- Bind DN: `uid=admin,cn=users,cn=accounts,dc=ocp4,dc=example,dc=com`
- Bind Password: `redhatocp`
- Insecure: `false`
- Query filter / attribute: `uid`
- Mapping Method: `claim`

Requirement:

- username `developer` must be able to log in using password `developer`.
