# Q2 Troubleshooting

Expected URL:

    ldaps://idm.ocp4.example.com/cn=users,cn=accounts,dc=ocp4,dc=example,dc=com?uid

Bind secret:

    oc create secret generic ldap-secret \
      -n openshift-config \
      --from-literal=bindPassword=redhatocp

CA:

    curl -k https://idm.ocp4.example.com/ipa/config/ca.crt -o /tmp/ca.crt

    oc create cm ca-config-map \
      -n openshift-config \
      --from-file=ca.crt=/tmp/ca.crt

Useful checks:

    oc get oauth cluster -o yaml
    oc get secret ldap-secret -n openshift-config -o yaml
    oc get cm ca-config-map -n openshift-config -o yaml
    oc get co authentication

Functional login test without overwriting the admin kubeconfig:

    oc login https://api.ocp4.example.com:6443 \
      -u developer \
      -p developer \
      --insecure-skip-tls-verify=true \
      --kubeconfig=/tmp/developer.kubeconfig

    oc --kubeconfig=/tmp/developer.kubeconfig whoami

Expected:

    developer

Preserve unrelated identity providers.


## Backup / recovery

The default setup does not delete the LDAP prerequisite objects.

Backup directory:

    ./q2-backup

CA certificate backup:

    ./q2-backup/ca.crt

Bind password backup:

    ./q2-backup/bindPassword

Recreate both:

    ./restore-prereqs.sh

Manual CA recreation:

    oc create configmap ca-config-map \
      -n openshift-config \
      --from-file=ca.crt=./q2-backup/ca.crt

Manual secret recreation:

    oc create secret generic ldap-secret \
      -n openshift-config \
      --from-literal=bindPassword="$(cat ./q2-backup/bindPassword)"
