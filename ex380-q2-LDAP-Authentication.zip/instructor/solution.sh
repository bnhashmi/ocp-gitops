#!/bin/bash
set -e

API="https://api.ocp4.example.com:6443"

oc login "$API" \
  -u admin \
  -p redhatocp \
  --insecure-skip-tls-verify=true >/dev/null

echo "==> Downloading IdM CA"
curl -k -sS \
  https://idm.ocp4.example.com/ipa/config/ca.crt \
  -o /tmp/ca.crt

echo "==> Creating bind secret"
oc create secret generic ldap-auth-secret \
  -n openshift-config \
  --from-literal=bindPassword=redhatocp \
  --dry-run=client -o yaml | oc apply -f -

echo "==> Creating CA ConfigMap"
oc create configmap ldap-auth-ca \
  -n openshift-config \
  --from-file=ca.crt=/tmp/ca.crt \
  --dry-run=client -o yaml | oc apply -f -

cat >/tmp/ex380-q2-idp.json <<'EOF'
{
  "name": "LDAP-AUTH-EX380",
  "mappingMethod": "claim",
  "type": "LDAP",
  "ldap": {
    "attributes": {
      "id": ["dn"],
      "email": ["mail"],
      "name": ["cn"],
      "preferredUsername": ["uid"]
    },
    "bindDN": "uid=admin,cn=users,cn=accounts,dc=ocp4,dc=example,dc=com",
    "bindPassword": {
      "name": "ldap-auth-secret"
    },
    "ca": {
      "name": "ldap-auth-ca"
    },
    "insecure": false,
    "url": "ldaps://idm.ocp4.example.com/cn=users,cn=accounts,dc=ocp4,dc=example,dc=com?uid"
  }
}
EOF

python3 - <<'PY' >/tmp/ex380-q2-oauth-new.json
import json, subprocess
obj=json.loads(subprocess.check_output(["oc","get","oauth","cluster","-o","json"]))
with open("/tmp/ex380-q2-idp.json") as f:
    wanted=json.load(f)
providers=obj.setdefault("spec",{}).get("identityProviders",[]) or []
providers=[p for p in providers if p.get("name")!="LDAP-AUTH-EX380"]
providers.append(wanted)
obj["spec"]["identityProviders"]=providers
obj.pop("status",None)
md=obj.get("metadata",{})
for k in ("creationTimestamp","generation","managedFields","resourceVersion","uid"):
    md.pop(k,None)
print(json.dumps(obj))
PY

oc replace -f /tmp/ex380-q2-oauth-new.json >/dev/null

echo "==> Waiting for authentication operator"
oc wait clusteroperator/authentication \
  --for=condition=Available=True \
  --timeout=300s

echo
echo "Reference solution applied."
