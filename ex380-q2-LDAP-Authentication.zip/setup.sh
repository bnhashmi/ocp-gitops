#!/bin/bash
set -e

API="https://api.ocp4.example.com:6443"
ADMIN_USER="admin"
ADMIN_PASSWORD="redhatocp"

echo "=== EX380 Q2 LDAP SETUP ==="

oc login "$API" \
  -u "$ADMIN_USER" \
  -p "$ADMIN_PASSWORD" \
  --insecure-skip-tls-verify=true >/dev/null

echo "==> Connected as $(oc whoami)"

echo "==> Backing up current OAuth"
oc get oauth cluster -o yaml > /tmp/ex380-q2-oauth-before.yaml

echo "==> Removing only LDAP-AUTH-EX380 if already configured"

python3 - <<'PY' >/tmp/ex380-q2-oauth-patched.json
import json, subprocess
obj=json.loads(subprocess.check_output(["oc","get","oauth","cluster","-o","json"]))
providers=obj.setdefault("spec",{}).get("identityProviders",[]) or []
obj["spec"]["identityProviders"]=[p for p in providers if p.get("name")!="LDAP-AUTH-EX380"]
obj.pop("status",None)
md=obj.get("metadata",{})
for k in ("creationTimestamp","generation","managedFields","resourceVersion","uid"):
    md.pop(k,None)
print(json.dumps(obj))
PY

oc replace -f /tmp/ex380-q2-oauth-patched.json >/dev/null

echo "==> Removing Q2 secret/configmap if present"
oc delete secret ldap-auth-secret \
  -n openshift-config \
  --ignore-not-found >/dev/null

oc delete configmap ldap-auth-ca \
  -n openshift-config \
  --ignore-not-found >/dev/null

rm -f /tmp/ex380-q2-developer.kubeconfig

echo
echo "SETUP COMPLETE"
echo "Other identity providers were preserved."
