#!/bin/bash
set -e

API="https://api.ocp4.example.com:6443"
ADMIN_USER="admin"
ADMIN_PASSWORD="redhatocp"

IDP_NAME="LDAP-AUTH-EX380"
SECRET_NAME="ldap-secret"
CA_CM="ca-config-map"

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
BACKUP_DIR="$SCRIPT_DIR/q2-backup"

echo "=== EX380 Q2 LDAP SETUP ==="

oc login "$API" \
  -u "$ADMIN_USER" \
  -p "$ADMIN_PASSWORD" \
  --insecure-skip-tls-verify=true >/dev/null

echo "==> Connected as $(oc whoami)"

mkdir -p "$BACKUP_DIR"

echo "==> Backing up current OAuth configuration"
oc get oauth cluster -o yaml > "$BACKUP_DIR/oauth-cluster-before.yaml"

echo "==> Backing up LDAP prerequisite objects if present"

if oc get secret "$SECRET_NAME" -n openshift-config >/dev/null 2>&1; then
  oc get secret "$SECRET_NAME" \
    -n openshift-config \
    -o jsonpath='{.data.bindPassword}' | base64 -d \
    > "$BACKUP_DIR/bindPassword"

  echo "    saved bind password -> $BACKUP_DIR/bindPassword"
else
  echo "    $SECRET_NAME does not currently exist"
fi

if oc get configmap "$CA_CM" -n openshift-config >/dev/null 2>&1; then
  oc get configmap "$CA_CM" \
    -n openshift-config \
    -o jsonpath='{.data.ca\.crt}' \
    > "$BACKUP_DIR/ca.crt"

  echo "    saved CA certificate -> $BACKUP_DIR/ca.crt"
else
  echo "    $CA_CM does not currently exist"
fi

echo "==> Preserving ldap-secret and ca-config-map"
echo "    They are NOT deleted by the default setup."

echo "==> Removing only the LDAP-AUTH-EX380 IDP if already configured"

python3 - <<'PY' > /tmp/ex380-q2-oauth-patched.json
import json, subprocess
obj=json.loads(subprocess.check_output(["oc","get","oauth","cluster","-o","json"]))
providers=obj.setdefault("spec",{}).get("identityProviders",[]) or []
obj["spec"]["identityProviders"]=[
    p for p in providers
    if p.get("name")!="LDAP-AUTH-EX380"
]
obj.pop("status",None)
md=obj.get("metadata",{})
for k in ("creationTimestamp","generation","managedFields","resourceVersion","uid"):
    md.pop(k,None)
print(json.dumps(obj))
PY

oc replace -f /tmp/ex380-q2-oauth-patched.json >/dev/null

rm -f /tmp/ex380-q2-developer.kubeconfig

echo
echo "SETUP COMPLETE"
echo
echo "Preserved:"
echo "  Secret:       $SECRET_NAME"
echo "  CA ConfigMap: $CA_CM"
echo
echo "Backups:"
echo "  $BACKUP_DIR"
