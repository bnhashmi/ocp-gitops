#!/bin/bash
set -e

API="https://api.ocp4.example.com:6443"
SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
BACKUP_DIR="$SCRIPT_DIR/q2-backup"

oc login "$API" \
  -u admin \
  -p redhatocp \
  --insecure-skip-tls-verify=true >/dev/null

echo "=== RESTORE Q2 LDAP PREREQUISITES ==="

if [ -s "$BACKUP_DIR/bindPassword" ]; then
  PASSWORD=$(cat "$BACKUP_DIR/bindPassword")

  oc create secret generic ldap-secret \
    -n openshift-config \
    --from-literal=bindPassword="$PASSWORD" \
    --dry-run=client -o yaml | oc apply -f -

  echo "Restored ldap-secret"
else
  echo "No bindPassword backup found."
fi

if [ -s "$BACKUP_DIR/ca.crt" ]; then
  oc create configmap ca-config-map \
    -n openshift-config \
    --from-file=ca.crt="$BACKUP_DIR/ca.crt" \
    --dry-run=client -o yaml | oc apply -f -

  echo "Restored ca-config-map"
else
  echo "No ca.crt backup found."
fi
