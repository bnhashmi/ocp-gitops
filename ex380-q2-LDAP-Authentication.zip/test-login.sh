#!/bin/bash
set -e

API="https://api.ocp4.example.com:6443"
KCFG="/tmp/ex380-q2-developer.kubeconfig"

rm -f "$KCFG"

echo "==> Testing developer/developer"

if oc login "$API" \
    -u developer \
    -p developer \
    --insecure-skip-tls-verify=true \
    --kubeconfig="$KCFG" >/tmp/ex380-q2-login.out 2>&1
then
  echo "PASS: login succeeded"
  echo -n "Identity: "
  oc --kubeconfig="$KCFG" whoami
else
  echo "FAIL: login failed"
  cat /tmp/ex380-q2-login.out
  exit 1
fi
