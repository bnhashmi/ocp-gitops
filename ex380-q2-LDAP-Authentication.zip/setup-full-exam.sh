#!/bin/bash
set -e

SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)

echo "=== EX380 Q2 FULL EXAM RESET ==="
echo "First creating backups using setup.sh..."

"$SCRIPT_DIR/setup.sh"

echo
echo "==> Removing LDAP prerequisite objects AFTER backup"

oc delete secret ldap-secret \
  -n openshift-config \
  --ignore-not-found

oc delete configmap ca-config-map \
  -n openshift-config \
  --ignore-not-found

echo
echo "FULL EXAM START STATE READY"
echo
echo "Backups remain in:"
echo "  $SCRIPT_DIR/q2-backup"
echo
echo "To recreate the prerequisite objects later:"
echo "  ./restore-prereqs.sh"
