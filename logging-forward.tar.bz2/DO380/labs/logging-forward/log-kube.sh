#!/bin/bash

echo "Filtering Kubernetes events on the logger-app namespace"
echo "Press Ctrl+C to exit"
echo

set -x

tail -f /var/log/openshift/infra.log | grep -Eo "\{.*}$" \
  | jq -c '.
    | select(.kubernetes.event.involvedObject.namespace == "logger-app")
    | [.kubernetes.event.involvedObject.kind,
    .kubernetes.event.involvedObject.name, .message]'
