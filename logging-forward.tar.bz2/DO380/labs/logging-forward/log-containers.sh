#!/bin/bash

echo "Filtering container logs from infrastructure log"
echo "Press Ctrl+C to exit"
echo

set -x

tail -f /var/log/openshift/infra.log | grep -Eo "\{.*}$" \
  | jq '. | select(.kubernetes.namespace_name == "openshift-storage")
    | .kubernetes.pod_name + " " + .message'
