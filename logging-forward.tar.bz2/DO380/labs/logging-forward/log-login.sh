#!/bin/bash

echo "Filtering user login events from audit log"
echo

set -x

grep -Eho "\{.*}$" /var/log/openshift/audit.log* \
  | jq '. | select(."audit.linux".type == "USER_LOGIN")
    | ."@timestamp" + " " + .hostname + " " + .message'
