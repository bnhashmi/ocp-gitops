#!/bin/bash

echo "Filtering audit logs for the developer user"
echo "Press Ctrl+C to exit"
echo

set -x

tail -f /var/log/openshift/audit.log* | grep -Eo "\{.*}$" \
  | jq -c '.|select(.user.username == "developer")
    | [.user.username, .annotations, .verb, .objectRef]'
