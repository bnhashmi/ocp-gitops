#!/bin/bash

echo "Filtering SSHD logs from infrastructure log"
echo "Press Ctrl+C to exit"
echo

set -x

tail -f /var/log/openshift/infra.log | grep -Eo "\{.*}$" \
  | jq '. | select(.systemd.u.SYSLOG_IDENTIFIER=="sshd")
    | .hostname + " " + .message'
