# Instructor Notes

## Intended broken state

Masters/control-plane:

    node-role.kubernetes.io/master=:NoSchedule

or equivalent control-plane NoSchedule protection.

Workers:

    ex380-scheduling=blocked:NoSchedule

All dedicated workers are therefore unavailable to normal application pods.

## Expected diagnosis

Useful commands:

    oc get nodes
    oc describe node worker01
    oc get node worker01 -o jsonpath='{.spec.taints}{"\n"}'

A normal test pod should remain Pending:

    oc new-project q1-test
    oc run hello --image=quay.io/openshifttest/hello-openshift:1.2.0
    oc describe pod hello

The scheduler event should mention an untolerated worker taint.

## Correct repair

Remove only the injected worker taint:

    oc adm taint node worker01 ex380-scheduling-
    oc adm taint node worker02 ex380-scheduling-
    oc adm taint node worker03 ex380-scheduling-

Do NOT:
- remove the master/control-plane NoSchedule taint
- add a toleration to the test workload
- schedule application workloads on masters

The requirement is that ordinary workloads run on workers without intervention.


## Optional Ruby S2I test

A second realistic test is:

    oc new-project q1-ruby-test

    oc new-app \
      openshift/ruby:25~https://github.com/sclorg/ruby-ex \
      --name=ruby-ex \
      -n q1-ruby-test

Then inspect:

    oc get builds,pods -n q1-ruby-test -o wide

    oc get events -n q1-ruby-test \
      --sort-by=.lastTimestamp

    oc describe pod -n q1-ruby-test <pod-name>

If the injected worker taint is still present, application/build pods can remain Pending
with scheduler messages about an untolerated taint.

After the scheduling fault is repaired, the application workload should be able to run
on workers normally.

Do not use the Ruby test as the only proof of scheduling health because a GitHub or
S2I build failure is a separate problem.
