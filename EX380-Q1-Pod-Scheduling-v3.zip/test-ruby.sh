#!/bin/bash
set -euo pipefail

API="${API:-https://api.ocp4.example.com:6443}"
USER="${USER:-admin}"
PASSWORD="${PASSWORD:-redhatocp}"
NS="${NS:-q1-ruby-test}"

echo "==> Logging in"
oc login "$API" -u "$USER" -p "$PASSWORD" \
  --insecure-skip-tls-verify=true >/dev/null

echo "==> Recreating test project: $NS"
oc delete project "$NS" --ignore-not-found --wait=false >/dev/null 2>&1 || true

for i in $(seq 1 60); do
  if ! oc get project "$NS" >/dev/null 2>&1; then
    break
  fi
  sleep 1
done

oc new-project "$NS" >/dev/null

echo "==> Creating Ruby S2I application"
echo "    oc new-app openshift/ruby:25~https://github.com/sclorg/ruby-ex"
oc new-app \
  openshift/ruby:25~https://github.com/sclorg/ruby-ex \
  --name=ruby-ex \
  -n "$NS"

echo
echo "==> Current build/application state"
oc get builds,pods -n "$NS" -o wide || true

echo
echo "Useful troubleshooting commands:"
echo "  oc get pods -n $NS -o wide"
echo "  oc get events -n $NS --sort-by=.lastTimestamp"
echo "  oc describe pod -n $NS <pod>"
echo "  oc logs -n $NS -f bc/ruby-ex"
echo
echo "If the build completes, wait for the application rollout with:"
echo "  oc rollout status deployment/ruby-ex -n $NS --timeout=300s"
echo
echo "If this environment creates a DeploymentConfig instead:"
echo "  oc rollout status dc/ruby-ex -n $NS --timeout=300s"
echo
echo "IMPORTANT: this is an optional test."
echo "A GitHub/build failure is not necessarily a scheduling failure."
