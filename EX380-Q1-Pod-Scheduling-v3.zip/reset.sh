#!/bin/bash
set -euo pipefail

API="${API:-https://api.ocp4.example.com:6443}"
USER="${USER:-admin}"
PASSWORD="${PASSWORD:-redhatocp}"

FAULT_KEY="ex380-scheduling"
FAULT_VALUE="blocked"
FAULT_EFFECT="NoSchedule"

TEST_IMAGE="quay.io/openshifttest/hello-openshift:1.2.0"

login_cluster() {
  oc login "$API" -u "$USER" -p "$PASSWORD" \
    --insecure-skip-tls-verify=true >/dev/null
}

get_masters() {
  local x
  x="$(oc get nodes -l node-role.kubernetes.io/master -o name 2>/dev/null | sed 's#node/##')"
  if [ -n "$x" ]; then
    printf '%s\n' "$x"
    return
  fi

  x="$(oc get nodes -l node-role.kubernetes.io/control-plane -o name 2>/dev/null | sed 's#node/##')"
  if [ -n "$x" ]; then
    printf '%s\n' "$x"
    return
  fi

  oc get nodes -o name | sed 's#node/##' | grep '^master' || true
}

get_workers() {
  # Prefer dedicated worker nodes by role label, excluding control-plane/master.
  oc get nodes -l node-role.kubernetes.io/worker -o json | python3 -c '
import sys,json
d=json.load(sys.stdin)
for item in d.get("items",[]):
    labels=item.get("metadata",{}).get("labels",{})
    if "node-role.kubernetes.io/master" in labels:
        continue
    if "node-role.kubernetes.io/control-plane" in labels:
        continue
    print(item["metadata"]["name"])
' 2>/dev/null
}


login_cluster

mapfile -t MASTERS < <(get_masters)
mapfile -t WORKERS < <(get_workers)

oc delete ns ex380-q1-grade --ignore-not-found --wait=false >/dev/null 2>&1 || true

echo "==> Re-protecting masters"
for node in "${MASTERS[@]}"; do
  oc adm taint node "$node" \
    node-role.kubernetes.io/master=:NoSchedule \
    --overwrite >/dev/null 2>&1 || \
  oc adm taint node "$node" \
    node-role.kubernetes.io/control-plane=:NoSchedule \
    --overwrite >/dev/null 2>&1 || true
done

echo "==> Restoring worker fault"
for node in "${WORKERS[@]}"; do
  oc adm taint node "$node" "${FAULT_KEY}-" >/dev/null 2>&1 || true
  oc adm taint node "$node" \
    "${FAULT_KEY}=${FAULT_VALUE}:${FAULT_EFFECT}" \
    --overwrite >/dev/null
done

echo "Reset complete."
