#!/usr/bin/env bash
set -euo pipefail

API="${API:-https://api.ocp4.example.com:6443}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASS="${ADMIN_PASS:-redhatocp}"
NS="${NS:-openshift-logging}"
SYSLOG_HOST="${SYSLOG_HOST:-utility.lab.example.com}"
CHANNEL="${CHANNEL:-stable-6.4}"
COLLECTOR_SA="${COLLECTOR_SA:-logcollector}"

say(){ printf '\n==> %s\n' "$*"; }
warn(){ printf 'WARNING: %s\n' "$*" >&2; }

command -v oc >/dev/null || { echo "oc command not found" >&2; exit 1; }

say "Logging in to ${API}"
oc login "$API" -u "$ADMIN_USER" -p "$ADMIN_PASS" --insecure-skip-tls-verify=true >/dev/null

say "Checking OpenShift version"
oc version
SERVER_MINOR=$(oc get clusterversion version -o jsonpath='{.status.desired.version}' 2>/dev/null || true)
case "$SERVER_MINOR" in
  4.18.*) : ;;
  *) warn "This pack targets OCP 4.18. Detected: ${SERVER_MINOR:-unknown}" ;;
esac

say "Ensuring namespace ${NS} exists"
oc create namespace "$NS" --dry-run=client -o yaml | oc apply -f - >/dev/null
oc label namespace "$NS" openshift.io/cluster-monitoring=true --overwrite >/dev/null

say "Ensuring Red Hat OpenShift Logging Operator ${CHANNEL} is installed"
cat <<YAML | oc apply -f - >/dev/null
apiVersion: operators.coreos.com/v1
kind: OperatorGroup
metadata:
  name: cluster-logging
  namespace: ${NS}
spec:
  upgradeStrategy: Default
---
apiVersion: operators.coreos.com/v1alpha1
kind: Subscription
metadata:
  name: cluster-logging
  namespace: ${NS}
spec:
  channel: ${CHANNEL}
  installPlanApproval: Automatic
  name: cluster-logging
  source: redhat-operators
  sourceNamespace: openshift-marketplace
YAML

say "Waiting for Logging 6.4 CRD and RBAC roles"
for i in {1..90}; do
  if oc get crd clusterlogforwarders.observability.openshift.io >/dev/null 2>&1 \
     && oc get clusterrole collect-application-logs >/dev/null 2>&1 \
     && oc get clusterrole collect-infrastructure-logs >/dev/null 2>&1 \
     && oc get clusterrole collect-audit-logs >/dev/null 2>&1; then
    break
  fi
  sleep 5
  if [[ $i -eq 90 ]]; then
    echo "Timed out waiting for Logging operator/CRD." >&2
    exit 1
  fi
done

say "Preparing collector service account and required permissions"
oc create sa "$COLLECTOR_SA" -n "$NS" --dry-run=client -o yaml | oc apply -f - >/dev/null
for role in collect-application-logs collect-infrastructure-logs collect-audit-logs; do
  oc adm policy add-cluster-role-to-user "$role" "system:serviceaccount:${NS}:${COLLECTOR_SA}" >/dev/null
 done

say "Resetting candidate-created Q5 resources"
oc delete clusterlogforwarder.observability.openshift.io --all -n "$NS" --ignore-not-found >/dev/null 2>&1 || true
oc delete deployment eventrouter -n "$NS" --ignore-not-found >/dev/null 2>&1 || true
oc delete configmap eventrouter -n "$NS" --ignore-not-found >/dev/null 2>&1 || true
oc delete serviceaccount eventrouter -n "$NS" --ignore-not-found >/dev/null 2>&1 || true
oc delete clusterrolebinding event-reader-binding --ignore-not-found >/dev/null 2>&1 || true
oc delete clusterrole event-reader --ignore-not-found >/dev/null 2>&1 || true

say "Checking syslog host reachability"
if getent hosts "$SYSLOG_HOST" >/dev/null 2>&1; then
  getent hosts "$SYSLOG_HOST" | head -1
else
  warn "DNS lookup failed for ${SYSLOG_HOST}. Fix lab DNS before attempting the question."
fi

if command -v nc >/dev/null 2>&1; then
  if nc -z -w2 "$SYSLOG_HOST" 514 >/dev/null 2>&1; then
    echo "TCP/514 reachable on ${SYSLOG_HOST}"
  else
    warn "TCP/514 was not reachable on ${SYSLOG_HOST}; the question assumes the syslog server is preconfigured."
  fi
fi

say "Exam state ready"
echo "API              : $API"
echo "Namespace        : $NS"
echo "Collector SA     : $COLLECTOR_SA (pre-created with app/infra/audit permissions)"
echo "Logging channel  : $CHANNEL"
echo "Syslog host      : $SYSLOG_HOST"
echo
echo "Student should now complete student/QUESTION.md"
