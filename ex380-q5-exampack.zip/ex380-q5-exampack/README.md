# EX380 Q5 Exam Pack — Log Forwarding + Event Router

This pack targets **OpenShift 4.18** with **Red Hat OpenShift Logging 6.4**.

## Files

- `setup.sh` — prepares the cluster-side prerequisites and resets Q5 state.
- `student/QUESTION.md` — candidate question only.
- `grade.sh` — semantic grader, score out of 100.
- `reset.sh` — removes candidate-created Q5 resources but leaves the operator/prerequisite collector SA.
- `instructor/solution-clf.yaml` — reference Logging 6.4 `ClusterLogForwarder` solution.
- `instructor/eventrouter-template.yaml` — Event Router v0.4 reference template.
- `instructor/solution.sh` — applies the reference solution.
- `instructor/utility-rsyslog-ex380.conf` — optional rsyslog receiver rules if rebuilding `utility.lab.example.com`.

## Default access

The scripts use these defaults, all overridable with environment variables:

```text
API=https://api.ocp4.example.com:6443
ADMIN_USER=admin
ADMIN_PASS=redhatocp
NS=openshift-logging
SYSLOG_HOST=utility.lab.example.com
```

## Instructor workflow

```bash
cd ex380-q5-exampack
./setup.sh
```

Give the student only `student/QUESTION.md` or show the task in the exam interface.

After the student finishes:

```bash
./grade.sh
```

To reset for another attempt:

```bash
./reset.sh
```

To validate the pack with the reference answer:

```bash
./reset.sh
./instructor/solution.sh
./grade.sh
```

## Grading model

The grader checks semantics rather than hard-coding output/pipeline names. It accepts either `tcp://utility.lab.example.com:514` or `udp://utility.lab.example.com:514`, but requires the correct `procId`, `appName`, input-to-output routing, collector authorization, a ready collector, and a ready Event Router using the exact required image.

### Score allocation

- Logging 6.4 API available: 5
- ClusterLogForwarder exists: 5
- ClusterLogForwarder Ready=True: 10
- App/infra/audit syslog destinations, routes, and tags: 45
- Collector service-account authorization: 10
- Ready Vector/collector DaemonSet: 5
- Event Router exact image/readiness/config/RBAC: 20

Practice pass threshold: **80/100**.

## Logging 6.4 note

Logging 6.4 uses `apiVersion: observability.openshift.io/v1` for `ClusterLogForwarder`. The collector service account needs the `collect-application-logs`, `collect-infrastructure-logs`, and `collect-audit-logs` cluster roles before those inputs are used. The Event Router reads Kubernetes Event objects and writes them to stdout so the logging collector can collect them.
