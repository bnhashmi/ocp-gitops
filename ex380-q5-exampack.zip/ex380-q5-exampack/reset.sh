#!/usr/bin/env bash
set -euo pipefail
API="${API:-https://api.ocp4.example.com:6443}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASS="${ADMIN_PASS:-redhatocp}"
NS="${NS:-openshift-logging}"

oc login "$API" -u "$ADMIN_USER" -p "$ADMIN_PASS" --insecure-skip-tls-verify=true >/dev/null
oc delete clusterlogforwarder.observability.openshift.io --all -n "$NS" --ignore-not-found >/dev/null 2>&1 || true
oc delete deployment eventrouter -n "$NS" --ignore-not-found >/dev/null 2>&1 || true
oc delete configmap eventrouter -n "$NS" --ignore-not-found >/dev/null 2>&1 || true
oc delete serviceaccount eventrouter -n "$NS" --ignore-not-found >/dev/null 2>&1 || true
oc delete clusterrolebinding event-reader-binding --ignore-not-found >/dev/null 2>&1 || true
oc delete clusterrole event-reader --ignore-not-found >/dev/null 2>&1 || true
echo "Q5 candidate resources reset. Logging operator and logcollector prerequisite remain installed."
