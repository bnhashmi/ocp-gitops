# EX380 Practice Pack — Q5 Configure Log Forwarding

Target cluster:

- API: `https://api.ocp4.example.com:6443`
- Namespace: `openshift-logging`
- External syslog host: `utility.lab.example.com`
- Syslog ports: `tcp/514` and `udp/514`
- Event Router image: `registry.ocp4.example.com:8443/openshift-logging/eventrouter-rhel9:v0.4`

## Task

Configure OpenShift Logging so that:

- The collector is Vector.
- Application logs are forwarded to `utility.lab.example.com:514` and use `procId: app`.
- Infrastructure logs are forwarded to `utility.lab.example.com:514` and use `procId: infra`.
- Audit logs are forwarded to `utility.lab.example.com:514` and use `procId: audit`.
- Every syslog output uses `appName: openshift`.
- The syslog receiver accepts TCP/514 and UDP/514. Either TCP or UDP is acceptable for the forwarding URL unless your instructor specifies one.
- Event Router is running in `openshift-logging` with the exact image:
  `registry.ocp4.example.com:8443/openshift-logging/eventrouter-rhel9:v0.4`

The external syslog server is expected to filter by PROCID into:

- `/var/log/ex380-app.log`
- `/var/log/ex380-infra.log`
- `/var/log/ex380-audit.log`

Do not modify or remove unrelated cluster resources.
