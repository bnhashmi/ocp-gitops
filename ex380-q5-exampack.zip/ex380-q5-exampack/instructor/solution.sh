#!/usr/bin/env bash
set -euo pipefail
API="${API:-https://api.ocp4.example.com:6443}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASS="${ADMIN_PASS:-redhatocp}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

oc login "$API" -u "$ADMIN_USER" -p "$ADMIN_PASS" --insecure-skip-tls-verify=true >/dev/null
oc apply -f "$ROOT/instructor/solution-clf.yaml"
oc process -f "$ROOT/instructor/eventrouter-template.yaml" | oc apply -f -

echo "Waiting for collector/EventRouter..."
oc rollout status deploy/eventrouter -n openshift-logging --timeout=180s
oc get clusterlogforwarder collector -n openshift-logging -o wide
oc get pods -n openshift-logging
