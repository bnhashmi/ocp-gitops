# EX380 Q1 — Troubleshooting Pod Scheduling Exam Pack v2

This version models the exam state more accurately:

- Master/control-plane nodes are protected with `NoSchedule`.
- The injected fault is placed on all dedicated worker nodes.
- Because every worker is tainted, normal application pods remain Pending.
- The student must repair the workers.
- Masters must remain protected; the student must **not** solve the problem by making masters schedulable.
- The grader creates ordinary application pods and verifies they run only on worker nodes.

Defaults:

    API:      https://api.ocp4.example.com:6443
    User:     admin
    Password: redhatocp

    Test image:
    quay.io/openshifttest/hello-openshift:1.2.0

Usage:

    ./setup.sh
    # student solves Q1
    ./grade.sh

Reset broken state:

    ./reset.sh

Reference repair:

    ./instructor/solution.sh


## Optional Ruby S2I scheduling test

In addition to the deterministic `hello-openshift` grading test, this pack includes:

    ./test-ruby.sh

It runs:

    oc new-app openshift/ruby:25~https://github.com/sclorg/ruby-ex

in project `q1-ruby-test`.

This is useful for reproducing a more realistic application deployment and inspecting scheduler events.

The Ruby test is intentionally **not scored**, because it also depends on:
- GitHub reachability
- the `openshift/ruby:25` ImageStreamTag
- successful S2I builds

For pure scheduling verification, use `./grade.sh`.


## v4 reliability fixes

This version does not use the shell variable `USER` for OpenShift authentication.
On the RHLS workstation `USER` is normally `student`, so the scripts now use:

    OCP_USER=admin

Every script also:
- prints its start banner
- prints the target API/user
- confirms `oc whoami`
- reports the exact line number on failure

You should now see output immediately when running:

    ./setup.sh
    ./grade.sh
    ./reset.sh

To override credentials:

    OCP_USER=admin PASSWORD=redhatocp ./setup.sh

If a script still behaves unexpectedly:

    bash -x ./setup.sh
