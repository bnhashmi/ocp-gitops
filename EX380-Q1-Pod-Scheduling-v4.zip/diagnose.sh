#!/bin/bash

echo "=== EX380 Q1 PACK DIAGNOSTICS ==="
echo "Shell: $SHELL"
echo "Linux user: ${USER:-unknown}"
echo "Bash: $BASH_VERSION"
echo

echo "oc:"
command -v oc || {
  echo "oc not found"
  exit 1
}

echo
echo "Current oc identity:"
oc whoami 2>&1 || true

echo
echo "Current API:"
oc whoami --show-server 2>&1 || true

echo
echo "Nodes:"
oc get nodes -o wide 2>&1 || true

echo
echo "Master/control-plane taints:"
for n in $(oc get nodes -l node-role.kubernetes.io/master -o name 2>/dev/null); do
  echo -n "$n: "
  oc get "$n" -o jsonpath='{.spec.taints}{"\n"}'
done

echo
echo "Dedicated worker taints:"
for n in $(oc get nodes -l node-role.kubernetes.io/worker -o name 2>/dev/null); do
  echo -n "$n: "
  oc get "$n" -o jsonpath='{.spec.taints}{"\n"}'
done
