#!/bin/bash
set -Eeuo pipefail

trap 'rc=$?; echo "ERROR: $(basename "$0") failed at line $LINENO (exit $rc)" >&2; exit $rc' ERR


API="${API:-https://api.ocp4.example.com:6443}"
OCP_USER="${OCP_USER:-admin}"
PASSWORD="${PASSWORD:-redhatocp}"

FAULT_KEY="ex380-scheduling"
FAULT_VALUE="blocked"
FAULT_EFFECT="NoSchedule"

TEST_IMAGE="quay.io/openshifttest/hello-openshift:1.2.0"

login_cluster() {
  echo "==> Connecting to $API as $OCP_USER"
  command -v oc >/dev/null || {
    echo "ERROR: oc command not found" >&2
    exit 1
  }

  oc login "$API" -u "$OCP_USER" -p "$PASSWORD" \
    --insecure-skip-tls-verify=true >/dev/null

  echo "==> Connected: $(oc whoami)"
}

get_masters() {
  local x
  x="$(oc get nodes -l node-role.kubernetes.io/master -o name 2>/dev/null | sed 's#node/##')"
  if [ -n "$x" ]; then
    printf '%s\n' "$x"
    return
  fi

  x="$(oc get nodes -l node-role.kubernetes.io/control-plane -o name 2>/dev/null | sed 's#node/##')"
  if [ -n "$x" ]; then
    printf '%s\n' "$x"
    return
  fi

  oc get nodes -o name | sed 's#node/##' | grep '^master' || true
}

get_workers() {
  # Prefer dedicated worker nodes by role label, excluding control-plane/master.
  oc get nodes -l node-role.kubernetes.io/worker -o json | python3 -c '
import sys,json
d=json.load(sys.stdin)
for item in d.get("items",[]):
    labels=item.get("metadata",{}).get("labels",{})
    if "node-role.kubernetes.io/master" in labels:
        continue
    if "node-role.kubernetes.io/control-plane" in labels:
        continue
    print(item["metadata"]["name"])
' 2>/dev/null
}


echo "=== EX380 Q1 REFERENCE SOLUTION ==="
login_cluster

mapfile -t WORKERS < <(get_workers)

echo "Removing only the injected fault from worker nodes:"
for node in "${WORKERS[@]}"; do
  oc adm taint node "$node" "${FAULT_KEY}-" || true
done

echo
echo "Do NOT remove the master/control-plane NoSchedule taint."
echo
oc get nodes
