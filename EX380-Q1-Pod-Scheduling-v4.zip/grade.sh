#!/bin/bash
set -Eeuo pipefail

trap 'rc=$?; echo "ERROR: $(basename "$0") failed at line $LINENO (exit $rc)" >&2; exit $rc' ERR


API="${API:-https://api.ocp4.example.com:6443}"
OCP_USER="${OCP_USER:-admin}"
PASSWORD="${PASSWORD:-redhatocp}"

FAULT_KEY="ex380-scheduling"
FAULT_VALUE="blocked"
FAULT_EFFECT="NoSchedule"

TEST_IMAGE="quay.io/openshifttest/hello-openshift:1.2.0"

login_cluster() {
  echo "==> Connecting to $API as $OCP_USER"
  command -v oc >/dev/null || {
    echo "ERROR: oc command not found" >&2
    exit 1
  }

  oc login "$API" -u "$OCP_USER" -p "$PASSWORD" \
    --insecure-skip-tls-verify=true >/dev/null

  echo "==> Connected: $(oc whoami)"
}

get_masters() {
  local x
  x="$(oc get nodes -l node-role.kubernetes.io/master -o name 2>/dev/null | sed 's#node/##')"
  if [ -n "$x" ]; then
    printf '%s\n' "$x"
    return
  fi

  x="$(oc get nodes -l node-role.kubernetes.io/control-plane -o name 2>/dev/null | sed 's#node/##')"
  if [ -n "$x" ]; then
    printf '%s\n' "$x"
    return
  fi

  oc get nodes -o name | sed 's#node/##' | grep '^master' || true
}

get_workers() {
  # Prefer dedicated worker nodes by role label, excluding control-plane/master.
  oc get nodes -l node-role.kubernetes.io/worker -o json | python3 -c '
import sys,json
d=json.load(sys.stdin)
for item in d.get("items",[]):
    labels=item.get("metadata",{}).get("labels",{})
    if "node-role.kubernetes.io/master" in labels:
        continue
    if "node-role.kubernetes.io/control-plane" in labels:
        continue
    print(item["metadata"]["name"])
' 2>/dev/null
}


echo "=== EX380 Q1 GRADER ==="
login_cluster

mapfile -t MASTERS < <(get_masters)
mapfile -t WORKERS < <(get_workers)

score=0

pass() {
  score=$((score+$1))
  echo "[PASS +$1] $2"
}

fail() {
  echo "[FAIL +0] $1"
}

echo "EX380 Q1 grader — Pod Scheduling"
echo "================================="
echo

# 1. Masters still protected
masters_ok=1
for node in "${MASTERS[@]}"; do
  if oc get node "$node" -o json | python3 -c '
import json,sys
d=json.load(sys.stdin)
ok=False
for t in d.get("spec",{}).get("taints",[]) or []:
    if t.get("effect")=="NoSchedule" and t.get("key") in (
        "node-role.kubernetes.io/master",
        "node-role.kubernetes.io/control-plane"
    ):
        ok=True
sys.exit(0 if ok else 1)
'; then
    echo "  $node remains protected"
  else
    echo "  $node is NOT protected by the expected NoSchedule taint"
    masters_ok=0
  fi
done

if [ "$masters_ok" -eq 1 ]; then
  pass 20 "Master/control-plane nodes remain protected from normal workloads"
else
  fail "Master/control-plane protection was removed"
fi

echo

# 2. Fault removed from all workers
workers_ok=1
for node in "${WORKERS[@]}"; do
  if oc get node "$node" -o json | python3 -c '
import json,sys
d=json.load(sys.stdin)
bad=False
for t in d.get("spec",{}).get("taints",[]) or []:
    if t.get("key")=="ex380-scheduling" and t.get("effect")=="NoSchedule":
        bad=True
sys.exit(0 if bad else 1)
'; then
    echo "  $node still has injected fault"
    workers_ok=0
  else
    echo "  $node is clear of injected fault"
  fi
done

if [ "$workers_ok" -eq 1 ]; then
  pass 30 "Injected scheduling fault removed from all workers"
else
  fail "One or more workers still have the injected NoSchedule taint"
fi

echo
echo "==> Creating grading namespace"
oc delete ns ex380-q1-grade --ignore-not-found --wait=false >/dev/null 2>&1 || true
for i in $(seq 1 60); do
  if ! oc get ns ex380-q1-grade >/dev/null 2>&1; then break; fi
  sleep 1
done
oc create ns ex380-q1-grade >/dev/null

# 3. Prove pod can run on every worker
all_workers_run=1
idx=0
for node in "${WORKERS[@]}"; do
  idx=$((idx+1))
  cat <<EOF | oc apply -f - >/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: worker-test-${idx}
  namespace: ex380-q1-grade
spec:
  restartPolicy: Never
  nodeSelector:
    kubernetes.io/hostname: ${node}
  containers:
  - name: hello
    image: ${TEST_IMAGE}
EOF
done

idx=0
for node in "${WORKERS[@]}"; do
  idx=$((idx+1))
  pod="worker-test-${idx}"
  if oc wait -n ex380-q1-grade \
      --for=condition=Ready "pod/${pod}" \
      --timeout=120s >/dev/null 2>&1; then
    actual=$(oc get pod "$pod" -n ex380-q1-grade \
      -o jsonpath='{.spec.nodeName}')
    echo "  $pod Running on $actual"
    [ "$actual" = "$node" ] || all_workers_run=0
  else
    echo "  $pod failed to become Ready on $node"
    all_workers_run=0
  fi
done

if [ "$all_workers_run" -eq 1 ]; then
  pass 30 "Normal hello-openshift pod runs on every worker node"
else
  fail "Normal application pod cannot run on every worker"
fi

echo

# 4. Create an unpinned normal deployment and confirm none of its pods land on masters
oc create deployment normal-app \
  -n ex380-q1-grade \
  --image="$TEST_IMAGE" >/dev/null

replicas="${#WORKERS[@]}"
[ "$replicas" -gt 3 ] && replicas=3
[ "$replicas" -lt 1 ] && replicas=1

oc scale deployment normal-app \
  -n ex380-q1-grade \
  --replicas="$replicas" >/dev/null

if oc rollout status deployment/normal-app \
     -n ex380-q1-grade \
     --timeout=120s >/dev/null 2>&1; then

  bad=0
  while read -r pod node; do
    [ -z "$pod" ] && continue
    echo "  $pod -> $node"
    for m in "${MASTERS[@]}"; do
      if [ "$node" = "$m" ]; then
        bad=1
      fi
    done
  done < <(
    oc get pod -n ex380-q1-grade \
      -l app=normal-app \
      -o jsonpath='{range .items[*]}{.metadata.name}{" "}{.spec.nodeName}{"\n"}{end}'
  )

  if [ "$bad" -eq 0 ]; then
    pass 20 "Ordinary application workloads schedule only onto workers"
  else
    fail "At least one ordinary application pod was scheduled onto a master"
  fi
else
  fail "Normal application deployment did not become available"
fi

echo
echo "--------------------------------"
echo "SCORE: ${score}/100"

if [ "$score" -eq 100 ]; then
  echo "RESULT: PASS"
else
  echo "RESULT: NO PASS"
fi
