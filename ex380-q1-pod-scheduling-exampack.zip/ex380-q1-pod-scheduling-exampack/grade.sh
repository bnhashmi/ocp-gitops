#!/bin/bash
set -euo pipefail

API="${API:-https://api.ocp4.example.com:6443}"
USER="${USER:-admin}"
PASSWORD="${PASSWORD:-redhatocp}"
TAINT_KEY="ex380-scheduling"
TAINT_VALUE="blocked"
TAINT_EFFECT="NoSchedule"
TEST_IMAGE="quay.io/openshifttest/hello-openshift:1.2.0"

login_cluster() {
  oc login "$API" -u "$USER" -p "$PASSWORD" --insecure-skip-tls-verify=true >/dev/null
}

get_workers() {
  # RHLS classroom nodes are normally named worker01, worker02, ...
  local workers
  workers="$(oc get nodes -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' | grep '^worker' || true)"
  if [ -n "$workers" ]; then
    printf '%s\n' "$workers"
    return 0
  fi

  # Fallback: nodes with worker label but without master/control-plane labels.
  oc get nodes -l node-role.kubernetes.io/worker -o json | \
    python3 -c '
import json,sys
d=json.load(sys.stdin)
for i in d.get("items",[]):
    labels=i.get("metadata",{}).get("labels",{})
    if "node-role.kubernetes.io/master" not in labels and "node-role.kubernetes.io/control-plane" not in labels:
        print(i["metadata"]["name"])
'
}

echo "EX380 Q1 grader — Troubleshooting Pod Scheduling"
echo "================================================="
login_cluster

mapfile -t WORKERS < <(get_workers)
if [ "${#WORKERS[@]}" -eq 0 ]; then
  echo "ERROR: No dedicated worker nodes found."
  exit 1
fi

score=0
passed=0
failed=0

pass() {
  local pts="$1"; shift
  score=$((score + pts))
  passed=$((passed + 1))
  echo "[PASS +${pts}] $*"
}

fail() {
  failed=$((failed + 1))
  echo "[FAIL +0] $*"
}

echo
echo "Check 1: worker scheduling configuration"
taint_problem=0
for node in "${WORKERS[@]}"; do
  if oc get node "$node" -o json | python3 -c '
import json,sys
d=json.load(sys.stdin)
bad=False
for t in d.get("spec",{}).get("taints",[]) or []:
    if t.get("key")=="ex380-scheduling" and t.get("effect")=="NoSchedule":
        bad=True
sys.exit(0 if bad else 1)
'; then
    echo "    $node still has ex380-scheduling:NoSchedule"
    taint_problem=1
  else
    echo "    $node is clear of the injected scheduling taint"
  fi
done

if [ "$taint_problem" -eq 0 ]; then
  pass 50 "Injected NoSchedule fault was removed from all dedicated workers"
else
  fail "One or more worker nodes still contain the injected NoSchedule taint"
fi

echo
echo "Check 2: ordinary application pod can run on every worker"
oc delete ns ex380-q1-grade --ignore-not-found --wait=false >/dev/null 2>&1 || true
for i in $(seq 1 60); do
  if ! oc get ns ex380-q1-grade >/dev/null 2>&1; then break; fi
  sleep 1
done

oc create ns ex380-q1-grade >/dev/null

all_running=1
idx=0
for node in "${WORKERS[@]}"; do
  idx=$((idx+1))
  name="hello-${idx}"
  cat <<EOF | oc apply -f - >/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: ${name}
  namespace: ex380-q1-grade
spec:
  restartPolicy: Never
  nodeSelector:
    kubernetes.io/hostname: ${node}
  containers:
  - name: hello
    image: ${TEST_IMAGE}
EOF
done

for node_idx in "${!WORKERS[@]}"; do
  idx=$((node_idx+1))
  node="${WORKERS[$node_idx]}"
  name="hello-${idx}"
  if oc wait -n ex380-q1-grade --for=condition=Ready "pod/${name}" --timeout=120s >/dev/null 2>&1; then
    actual=$(oc get pod "$name" -n ex380-q1-grade -o jsonpath='{.spec.nodeName}')
    echo "    $name is Running on $actual"
    if [ "$actual" != "$node" ]; then
      all_running=0
    fi
  else
    echo "    $name did not become Ready on $node"
    oc get pod "$name" -n ex380-q1-grade -o wide || true
    oc describe pod "$name" -n ex380-q1-grade | tail -30 || true
    all_running=0
  fi
done

if [ "$all_running" -eq 1 ]; then
  pass 50 "The hello-openshift image runs normally on every dedicated worker"
else
  fail "An ordinary hello-openshift pod could not run on every dedicated worker"
fi

echo
echo "-------------------------------------------------"
echo "SCORE: ${score}/100"
if [ "$score" -eq 100 ]; then
  echo "RESULT: PASS"
else
  echo "RESULT: NO PASS"
fi
echo "Checks passed: $passed  failed: $failed"

# Leave the grading pods in place so the student can inspect them after grading.
