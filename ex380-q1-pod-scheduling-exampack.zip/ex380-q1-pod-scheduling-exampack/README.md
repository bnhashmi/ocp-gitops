# EX380 Q1 — Troubleshooting Pod Scheduling Exam Pack

Target lab defaults:
- API: https://api.ocp4.example.com:6443
- Admin user: admin
- Admin password: redhatocp
- Test image: quay.io/openshifttest/hello-openshift:1.2.0

This pack creates a realistic scheduling fault by applying a NoSchedule taint to all dedicated worker nodes.
The student must diagnose and correct the cluster so an ordinary application pod can run on any worker node.

Files:
- setup.sh — prepares the broken exam state
- grade.sh — grades the student's repair
- reset.sh — restores the broken exam state for another attempt
- student/QUESTION.md — student-facing task
- instructor/solution.sh — reference repair
- instructor/troubleshooting.md — instructor notes

Quick use:

    ./setup.sh
    # student solves Q1
    ./grade.sh

To restore the broken state:

    ./reset.sh

To apply the reference repair:

    ./instructor/solution.sh
