#!/bin/bash
set -euo pipefail

API="${API:-https://api.ocp4.example.com:6443}"
USER="${USER:-admin}"
PASSWORD="${PASSWORD:-redhatocp}"
TAINT_KEY="ex380-scheduling"
TAINT_VALUE="blocked"
TAINT_EFFECT="NoSchedule"
TEST_IMAGE="quay.io/openshifttest/hello-openshift:1.2.0"

login_cluster() {
  oc login "$API" -u "$USER" -p "$PASSWORD" --insecure-skip-tls-verify=true >/dev/null
}

get_workers() {
  # RHLS classroom nodes are normally named worker01, worker02, ...
  local workers
  workers="$(oc get nodes -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' | grep '^worker' || true)"
  if [ -n "$workers" ]; then
    printf '%s\n' "$workers"
    return 0
  fi

  # Fallback: nodes with worker label but without master/control-plane labels.
  oc get nodes -l node-role.kubernetes.io/worker -o json | \
    python3 -c '
import json,sys
d=json.load(sys.stdin)
for i in d.get("items",[]):
    labels=i.get("metadata",{}).get("labels",{})
    if "node-role.kubernetes.io/master" not in labels and "node-role.kubernetes.io/control-plane" not in labels:
        print(i["metadata"]["name"])
'
}

echo "==> Connecting to $API as $USER"
login_cluster

mapfile -t WORKERS < <(get_workers)
if [ "${#WORKERS[@]}" -eq 0 ]; then
  echo "ERROR: No dedicated worker nodes found."
  exit 1
fi

echo "==> Dedicated worker nodes:"
printf '    %s\n' "${WORKERS[@]}"

echo "==> Removing any previous Q1 grading namespace"
oc delete ns ex380-q1-grade --ignore-not-found --wait=false >/dev/null 2>&1 || true

echo "==> Preparing broken scheduling state"
for node in "${WORKERS[@]}"; do
  # Remove any old copy first to make setup idempotent.
  oc adm taint node "$node" "${TAINT_KEY}-" >/dev/null 2>&1 || true
  oc adm taint node "$node" "${TAINT_KEY}=${TAINT_VALUE}:${TAINT_EFFECT}" --overwrite >/dev/null
  echo "    tainted $node with ${TAINT_KEY}=${TAINT_VALUE}:${TAINT_EFFECT}"
done

echo
echo "Q1 exam state is ready."
echo "Application pods without a matching toleration should not schedule onto the dedicated workers."
