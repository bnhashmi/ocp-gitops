#!/bin/bash
set -euo pipefail

API="${API:-https://api.ocp4.example.com:6443}"
USER="${USER:-admin}"
PASSWORD="${PASSWORD:-redhatocp}"
TAINT_KEY="ex380-scheduling"

oc login "$API" -u "$USER" -p "$PASSWORD" --insecure-skip-tls-verify=true >/dev/null

WORKERS=$(oc get nodes -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' | grep '^worker' || true)
if [ -z "$WORKERS" ]; then
  WORKERS=$(oc get nodes -l node-role.kubernetes.io/worker -o name | sed 's#node/##')
fi

echo "Removing the scheduling taint from worker nodes:"
for node in $WORKERS; do
  oc adm taint node "$node" "${TAINT_KEY}-" || true
done

echo
echo "Verify:"
oc get nodes
for node in $WORKERS; do
  echo -n "$node taints: "
  oc get node "$node" -o jsonpath='{.spec.taints}{"\n"}'
done
