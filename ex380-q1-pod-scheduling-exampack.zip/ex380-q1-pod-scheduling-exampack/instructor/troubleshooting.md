# Instructor troubleshooting notes

Useful diagnosis commands:

    oc get nodes
    oc describe node worker01 | grep -A3 -i Taints
    oc get node worker01 -o jsonpath='{.spec.taints}{"\n"}'

Create a normal test pod:

    oc new-project q1-test
    oc run hello --image=quay.io/openshifttest/hello-openshift:1.2.0

If the fault is present:

    oc get pod
    oc describe pod hello

The scheduling events should indicate that worker nodes have an untolerated taint.

Reference repair:

    oc adm taint node worker01 ex380-scheduling-
    oc adm taint node worker02 ex380-scheduling-
    oc adm taint node worker03 ex380-scheduling-

Do not solve the task by adding a toleration to the test workload. The requirement is that ordinary application pods can run on any worker node without intervention.
